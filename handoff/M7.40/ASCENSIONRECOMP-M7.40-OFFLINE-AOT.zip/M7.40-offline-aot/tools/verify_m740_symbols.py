#!/usr/bin/env python3
"""Require every M7.40 generated native entrypoint in the final Mach-O."""
from __future__ import annotations
import argparse
from pathlib import Path


def verify(nm_text: str, manifest_text: str) -> int:
    expected = manifest_text.splitlines()
    if not expected or len(expected) != len(set(expected)):
        raise ValueError("M7.40 symbol manifest is empty or has duplicates")
    if any(not name.startswith("ar_m740_game_ppu_") or len(name) != 25
           for name in expected):
        raise ValueError("invalid M7.40 symbol manifest entry")
    defined = []
    for line in nm_text.splitlines():
        fields = line.split()
        if len(fields) >= 3 and fields[-2] in ("T", "t"):
            symbol = fields[-1]
            if symbol.startswith("_"):
                symbol = symbol[1:]
            if symbol.startswith("ar_m740_game_ppu_"):
                defined.append(symbol)
    if len(defined) != len(set(defined)) or set(defined) != set(expected):
        raise ValueError(
            "M7.40 final Mach-O symbol mismatch: "
            f"missing={len(set(expected)-set(defined))}, "
            f"extra={len(set(defined)-set(expected))}, "
            f"duplicate={len(defined)-len(set(defined))}"
        )
    return len(defined)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("nm_file", type=Path)
    parser.add_argument("manifest_file", type=Path)
    args = parser.parse_args()
    count = verify(args.nm_file.read_text(), args.manifest_file.read_text())
    print(f"M7.40 final Mach-O verified: {count} native PPC entrypoints")


if __name__ == "__main__":
    main()
