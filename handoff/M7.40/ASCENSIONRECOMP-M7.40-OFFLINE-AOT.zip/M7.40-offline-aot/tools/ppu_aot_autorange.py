#!/usr/bin/env python3
"""Conservative, ELF-local PPU OPD/CFG range discovery for the prototype AOT.

The output is a candidate manifest, not proof of function boundaries or
execution. It deliberately rejects ambiguous inter-function control flow,
oversized bodies, fall-through across OPD boundaries, and non-contiguous CFGs.
"""
from __future__ import annotations
import argparse
import bisect
import json
import struct
from collections import Counter
from pathlib import Path


def sx(value: int, bits: int) -> int:
    return value - (1 << bits) if value & (1 << (bits - 1)) else value


def parse_elf(path: Path):
    data = path.read_bytes()
    if len(data) < 64 or data[:7] != b"\x7fELF\x02\x02\x01":
        raise ValueError("ELF64 big-endian required")
    (etype, machine, version, entry, phoff, shoff, flags, ehsize, phsize,
     phnum, shsize, shnum, shstridx) = struct.unpack_from(">HHIQQQIHHHHHH", data, 16)
    if etype != 2 or machine != 21 or version != 1:
        raise ValueError("expected PS3 PPU ET_EXEC")
    if phsize < 56 or phnum > 256 or phoff + phsize * phnum > len(data):
        raise ValueError("invalid program-header table")
    if shsize < 64 or shnum > 4096 or shoff + shsize * shnum > len(data):
        raise ValueError("invalid section-header table")
    ph = [struct.unpack_from(">IIQQQQQQ", data, phoff + i * phsize)
          for i in range(phnum)]
    sh = [struct.unpack_from(">IIQQQQIIQQ", data, shoff + i * shsize)
          for i in range(shnum)]
    if shstridx >= len(sh):
        raise ValueError("invalid shstrtab index")
    name_sec = sh[shstridx]
    name_bytes = data[name_sec[4]:name_sec[4] + name_sec[5]]
    def sec_name(sec):
        off = sec[0]
        end = name_bytes.find(b"\0", off) if off < len(name_bytes) else -1
        return name_bytes[off:end].decode("utf-8", "replace") if end >= 0 else "?"

    loads = []
    code = []
    for row in ph:
        typ, pflags, off, va, _pa, filesz, memsz, _align = row
        if typ == 1 and filesz:
            if off + filesz > len(data):
                raise ValueError("truncated PT_LOAD")
            loads.append((va, va + filesz, off))
            if pflags & 1:
                code.append((va, va + filesz, off))

    def read_va(va, n):
        for lo, hi, off in loads:
            if lo <= va and va + n <= hi:
                return data[off + va - lo:off + va - lo + n]
        return None

    containing = [(sec[5], i, sec) for i, sec in enumerate(sh)
                  if sec[5] and sec[3] <= entry < sec[3] + sec[5]]
    if not containing:
        raise ValueError("ELF entry descriptor section not found")
    _size, opd_index, opd_sec = min(containing)
    opd_raw = read_va(opd_sec[3], opd_sec[5])
    if opd_raw is None:
        raise ValueError("OPD section is not PT_LOAD mapped")

    def is_code(va):
        return any(lo <= va < hi for lo, hi, _off in code)
    starts = set()
    for off in range(0, max(0, len(opd_raw) - 7), 8):
        fn, _toc = struct.unpack_from(">II", opd_raw, off)
        if fn & 3 == 0 and is_code(fn):
            starts.add(fn)
    if not starts:
        raise ValueError("no executable PPU entries recovered from OPD")
    return data, code, sorted(starts), {
        "elf_entry_descriptor": hex(entry),
        "opd_section": {"index": opd_index, "name": sec_name(opd_sec),
                        "address": hex(opd_sec[3]), "size": opd_sec[5]},
        "opd_unique_code_entries": len(starts),
        "executable_ranges": [{"start": hex(lo), "end": hex(hi)}
                              for lo, hi, _ in code],
    }


def find_range(data, code, start, starts, starts_set, max_words):
    seg = next(((lo, hi, off) for lo, hi, off in code if lo <= start < hi), None)
    if seg is None:
        return None, "entry_not_in_executable_segment"
    seg_lo, seg_hi, seg_off = seg
    pos = bisect.bisect_right(starts, start)
    next_entry = starts[pos] if pos < len(starts) else seg_hi
    limit = min(seg_hi, next_entry, start + max_words * 4)
    if limit <= start:
        return None, "empty_or_overlapped_opd_interval"

    def read_word(pc):
        if not (seg_lo <= pc and pc + 4 <= seg_hi) or pc & 3:
            return None
        return struct.unpack_from(">I", data, seg_off + pc - seg_lo)[0]

    todo = [start]
    seen = set()
    exits = 0
    linked = 0
    while todo:
        pc = todo.pop()
        if pc in seen:
            continue
        if pc < start or pc >= limit or pc & 3:
            return None, "reachable_edge_crosses_inferred_bound"
        if pc != start and pc in starts_set:
            return None, "fallthrough_or_local_edge_enters_other_opd"
        word = read_word(pc)
        if word is None:
            return None, "reachable_pc_not_file_backed_executable"
        seen.add(pc)
        op = word >> 26
        fall = pc + 4
        succ = []

        if op == 18:  # b / bl
            delta = sx(word & 0x03fffffc, 26)
            target = delta if word & 2 else pc + delta
            link = bool(word & 1)
            if link:
                linked += 1
                if start <= target < limit and target not in (starts_set - {start}):
                    succ.extend((target, fall))
                else:
                    succ.append(fall)
            elif start <= target < limit and (target == start or target not in starts_set):
                succ.append(target)
            elif target in starts_set:
                exits += 1
            else:
                return None, "unlinked_branch_target_not_proven_function_entry"

        elif op == 16:  # bc / bcl
            delta = sx(word & 0xfffc, 16)
            target = delta if word & 2 else pc + delta
            bo = (word >> 21) & 31
            unconditional = (bo & 20) == 20
            link = bool(word & 1)
            local = start <= target < limit and (target == start or target not in starts_set)
            if link:
                linked += 1
                if local:
                    succ.append(target)
                elif target not in starts_set and not any(lo <= target < hi for lo, hi, _ in code):
                    return None, "linked_branch_target_not_executable_or_opd"
                if not unconditional:
                    succ.append(fall)
                elif not local:
                    succ.append(fall)
            else:
                if local:
                    succ.append(target)
                elif target in starts_set:
                    exits += 1
                else:
                    return None, "conditional_or_tail_branch_target_ambiguous"
                if not unconditional:
                    succ.append(fall)

        elif op == 19 and ((word >> 1) & 1023) in (16, 528):  # bclr / bcctr
            xo = (word >> 1) & 1023
            bo = (word >> 21) & 31
            unconditional = (bo & 20) == 20
            if word & 1:
                linked += 1
                succ.append(fall)
            else:
                exits += 1
                if not unconditional:
                    succ.append(fall)
        else:
            succ.append(fall)

        for nxt in succ:
            if nxt == limit:
                return None, "reachable_fallthrough_hits_next_opd_or_scan_limit"
            if nxt < seg_lo or nxt + 4 > seg_hi:
                return None, "reachable_edge_outside_executable_segment"
            if nxt not in seen:
                todo.append(nxt)

    if not seen:
        return None, "empty_cfg"
    end = max(seen) + 4
    nwords = (end - start) // 4
    if nwords > max_words:
        return None, "function_exceeds_max_words"
    interval = set(range(start, end, 4))
    if seen != interval:
        return None, "noncontiguous_cfg_or_embedded_data"
    return {"start": hex(start), "end": hex(end),
            "instructions": nwords, "reachable_instructions": len(seen),
            "linked_edges": linked, "external_tail_edges": exits}, None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--elf", required=True, type=Path)
    ap.add_argument("--functions-out", required=True, type=Path)
    ap.add_argument("--report-out", required=True, type=Path)
    ap.add_argument("--max-words", type=int, default=512)
    args = ap.parse_args()
    data, code, starts, meta = parse_elf(args.elf)
    starts_set = set(starts)
    accepted, failures = [], Counter()
    samples = []
    for start in starts:
        candidate, reason = find_range(data, code, start, starts, starts_set,
                                       args.max_words)
        if candidate:
            accepted.append(candidate)
        else:
            failures[reason] += 1
            if len(samples) < 100:
                samples.append({"start": hex(start), "reason": reason})
    args.functions_out.parent.mkdir(parents=True, exist_ok=True)
    args.report_out.parent.mkdir(parents=True, exist_ok=True)
    args.functions_out.write_text(json.dumps(
        [{"start": row["start"], "end": row["end"]} for row in accepted],
        indent=2) + "\n", encoding="utf-8")
    report = {
        "schema": "ascension-recomp/offline-opd-cfg-autorange-v1",
        "input_sha256": __import__("hashlib").sha256(data).hexdigest(),
        "elf_size_bytes": len(data),
        **meta,
        "max_words_per_candidate": args.max_words,
        "cfg_bounded_candidates": len(accepted),
        "rejected": sum(failures.values()),
        "rejection_reasons": dict(failures.most_common()),
        "rejection_samples": samples,
        "warning": "CFG-derived candidate ranges are conservative estimates; not symbol sizes, not semantic proof, and not evidence of device execution."
    }
    args.report_out.write_text(json.dumps(report, indent=2) + "\n",
                               encoding="utf-8")
    print(f"OPD entries={len(starts)} CFG-bounded={len(accepted)} "
          f"rejected={sum(failures.values())}")
    print("rejections:", dict(failures.most_common(10)))


if __name__ == "__main__":
    main()
