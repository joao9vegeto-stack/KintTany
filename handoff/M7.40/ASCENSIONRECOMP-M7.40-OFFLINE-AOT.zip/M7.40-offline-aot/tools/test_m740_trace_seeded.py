#!/usr/bin/env python3
"""Host execution checks for the trace-seeded M7.40 PPC block."""
from __future__ import annotations
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from ppu_cfg_lifter import PPUImage, lift  # noqa: E402

ELF = ROOT.parent / "upload" / "GOWA(1).ELF"
START = 0x524C54
END = 0x524C74
EXPECTED = [0x1CC60E10, 0x7CC62A14, 0x3929AE80, 0x7D4A3214,
            0x7D4A07B4, 0x7C005214, 0x7D290215, 0x4180008C]

HARNESS = r'''#include <stdint.h>
#include <stdio.h>
#include "ppu_context.h"
typedef ppu_context ppu_ctx;
int ar_m740_trace_00524c54(ppu_ctx *);
int ar_test_mulli_negative(ppu_ctx *);
static uint64_t sx32(uint32_t v) { return (uint64_t)(int64_t)(int32_t)v; }
static int check_block(uint64_t g6,uint64_t g5,uint64_t g9,
                       uint64_t g10,uint64_t g0,uint32_t xer,uint32_t oldcr) {
    ppu_context c={0};
    c.gpr[6]=g6;c.gpr[5]=g5;c.gpr[9]=g9;c.gpr[10]=g10;c.gpr[0]=g0;
    c.xer=xer;c.cr=oldcr;
    uint64_t e6=g6*UINT64_C(3600)+g5;
    uint64_t e9=g9+(uint64_t)(int64_t)-20864;
    uint64_t e10=sx32((uint32_t)(g10+e6));
    uint64_t e0=g0+e10;
    e9+=e0;
    const uint32_t field=((int64_t)e9<0)?8u:(e9?4u:2u)|((xer>>31)&1u);
    const uint32_t crflag=((int64_t)e9<0)?8u:(e9?4u:2u);
    const uint32_t expected_cr=(oldcr&UINT32_C(0x0fffffff))|
                               ((crflag|((xer>>31)&1u))<<28u);
    (void)field;
    const uint64_t pc=((expected_cr&UINT32_C(0x80000000))?
                       UINT64_C(0x524cfc):UINT64_C(0x524c74));
    if(ar_m740_trace_00524c54(&c)!=1 || c.gpr[6]!=e6 || c.gpr[9]!=e9 ||
       c.gpr[10]!=e10 || c.gpr[0]!=e0 || c.cr!=expected_cr || c.cia!=pc)
       return 1;
    return 0;
}
int main(void) {
    if(check_block(0,0,0,0,0,UINT32_C(0x80000000),UINT32_C(0x12345678))) return 1;
    if(check_block(0,0,0,0,30000,UINT32_C(0x80000000),UINT32_C(0x12345678))) return 2;
    if(check_block(0,0,0,0,20864,0,UINT32_C(0x12345678))) return 3;
    if(check_block(UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_C(0x7fffffff),
                   UINT64_C(0x8000000000000000),UINT32_C(0x80000000),0)) return 4;
    ppu_context c={0}; c.gpr[4]=UINT64_C(0x8000000000000001);
    if(ar_test_mulli_negative(&c)!=0 || c.gpr[3]!=UINT64_C(0x7ffffffffffffffd)) return 5;
    puts("M7.40 trace-seeded AOT host semantics PASS (4 PPC block cases + signed MULLI)");
    return 0;
}
'''


def run() -> None:
    words = EXPECTED
    if ELF.exists():
        image = PPUImage(ELF)
        if list(image.words(START, END)) != EXPECTED:
            raise SystemExit("M7.40 block words differ from the authenticated trace seed")
    block, _ = lift(words, START, "ar_m740_trace_00524c54",
                    allow_conditional_terminal=True)
    # mulli r3,r4,-3 followed by blr tests sign extension and modulo 2^64.
    mulli = (7 << 26) | (3 << 21) | (4 << 16) | 0xFFFD
    source, hist = lift([mulli, 0x4E800020], 0x1000,
                        "ar_test_mulli_negative")
    if hist.get("mulli") != 1:
        raise SystemExit("MULLI did not enter the AOT opcode manifest")
    with tempfile.TemporaryDirectory(prefix="m740-aot-") as td:
        out = Path(td)
        (out / "block.c").write_text(block)
        (out / "mulli.c").write_text(source)
        (out / "test.c").write_text(HARNESS)
        cc = ["cc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
              "-Wno-unused-label",
              "-I", str(ROOT / "stubs")]
        for src, obj in (("block.c", "block.o"), ("mulli.c", "mulli.o"),
                         ("test.c", "test.o")):
            subprocess.run(cc + ["-c", str(out / src), "-o", str(out / obj)],
                           check=True)
        exe = out / "test"
        subprocess.run(["cc", str(out / "block.o"), str(out / "mulli.o"),
                        str(out / "test.o"), "-o", str(exe)], check=True)
        subprocess.run([str(exe)], check=True)


if __name__ == "__main__":
    run()
