#ifndef TEST_PPU_VMX_CELL_H
#define TEST_PPU_VMX_CELL_H
#include "ppu_context.h"
int ar_vmx_splat_imm(ppu_context *, unsigned, unsigned, unsigned);
int ar_vmx_splatw(ppu_context *, unsigned, unsigned, unsigned);
int ar_vmx_guest_load(ppu_context *, unsigned, uint64_t, unsigned);
int ar_vmx_guest_store(const ppu_context *, unsigned, uint64_t, unsigned);
#endif
