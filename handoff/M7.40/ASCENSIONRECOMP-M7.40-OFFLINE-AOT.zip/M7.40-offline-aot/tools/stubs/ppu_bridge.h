#ifndef TEST_PPU_BRIDGE_H
#define TEST_PPU_BRIDGE_H
#include <stdint.h>
#include "ppu_context.h"
enum { AR_OK=0, AR_TAIL=1, AR_BAD_ARGS=-1, AR_MEM_FAULT=-2,
       AR_UNRESOLVED=-3, AR_BUDGET=-4, AR_DEPTH=-5, AR_DUPLICATE=-6,
       AR_NO_MEMORY=-7, AR_MISSING_HLE=-8, AR_HLE_FAILURE=-9,
       AR_MISSING_LV2=-10, AR_LV2_FAILURE=-11, AR_PPC_UNSUPPORTED=-12 };
int ar_register(uint32_t, int (*)(ppu_context *));
int ar_last_error(void);
int ar_vm_read_bytes(uint64_t, void *, size_t);
int ar_vm_load(uint64_t, const void *, size_t);
#endif
