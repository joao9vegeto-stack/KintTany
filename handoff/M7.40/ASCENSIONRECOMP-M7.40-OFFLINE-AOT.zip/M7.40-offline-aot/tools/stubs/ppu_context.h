#ifndef TEST_PPU_CONTEXT_H
#define TEST_PPU_CONTEXT_H
#include <stdint.h>
typedef union { uint64_t _u64[2]; } ppu_vr;
typedef struct ppu_context {
    uint64_t gpr[32];
    double fpr[32];
    ppu_vr vr[32];
    uint32_t cr;
    uint64_t lr;
    uint64_t ctr;
    uint32_t xer;
    uint32_t fpscr;
    uint32_t vscr;
    uint64_t cia;
} ppu_context;
#endif
