#ifndef TEST_PPU_FP_SCALAR_H
#define TEST_PPU_FP_SCALAR_H
#include <stdint.h>
#include "ppu_context.h"
int ar_fp_load(ppu_context *, unsigned, uint64_t, int);
int ar_fp_store(ppu_context *, unsigned, uint64_t, int);
int ar_fp_fcfid(ppu_context *, unsigned, unsigned);
int ar_fp_fdiv(ppu_context *, unsigned, unsigned, unsigned);
#endif
