#!/usr/bin/env python3
"""Build a split, duplicate-safe native C batch from a PPU ELF and CFG map."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path

from ppu_aot_build import build as build_monolithic
from ppu_cfg_lifter import PROLOGUE


FUNCTION_RE = re.compile(
    r"^int ar_game_ppu_[0-9a-f]{8}\(ppu_ctx \*c\) \{\n.*?^}\n",
    re.MULTILINE | re.DOTALL)


def split_batch(elf: Path, functions: Path, output: Path, prefix: str,
                max_chunk_bytes: int, require_entry: int | None) -> dict:
    if not re.fullmatch(r"[a-z][a-z0-9_]{0,15}", prefix):
        raise ValueError("prefix must be a short lowercase C identifier stem")
    if max_chunk_bytes < 100_000:
        raise ValueError("max_chunk_bytes is too small")
    output.mkdir(parents=True, exist_ok=True)
    runtime = output / "runtime"
    runtime.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="ppu-aot-batch-") as tmp:
        tmpdir = Path(tmp)
        manifest = build_monolithic(elf, functions, tmpdir, require_entry)
        generated = (tmpdir / "ascension_private_aot.c").read_text()
        bodies = FUNCTION_RE.findall(generated)
        if len(bodies) != manifest["generated_functions"]:
            raise ValueError("generated function count and source parse differ")
        newstem = f"ar_{prefix}_game_ppu_"
        bodies = [body.replace("ar_game_ppu_", newstem) for body in bodies]
        header = (
            "#include <stddef.h>\n#include <string.h>\n#include \"ppu_bridge.h\"\n"
            "#include \"ppu_vmx_cell.h\"\n#include \"ppu_fp_scalar.h\"\n"
            + PROLOGUE.replace("static inline", "static inline __attribute__((unused))")
            + "\n"
        )
        chunks: list[list[str]] = []
        current: list[str] = []
        size = len(header.encode())
        for body in bodies:
            extra = len(body.encode()) + 100
            if current and size + extra > max_chunk_bytes:
                chunks.append(current)
                current = []
                size = len(header.encode())
            current.append(body)
            size += extra
        if current:
            chunks.append(current)

        registrations: list[str] = []
        for index, chunk in enumerate(chunks):
            stem = f"ppu_{prefix}_offline_aot_{index:02d}"
            addresses: list[str] = []
            for body in chunk:
                match = re.search(re.escape(newstem) + r"([0-9a-f]{8})", body)
                if not match:
                    raise ValueError("renamed entry symbol missing")
                addresses.append(match.group(1))
            lines = [f"\nint ar_{prefix}_register_chunk_{index:02d}(void){{", "  int rc;"]
            for address in addresses:
                lines.append(
                    f"  rc=ar_register(UINT32_C(0x{address}),{newstem}{address});"
                    " if(rc!=AR_OK && rc!=AR_DUPLICATE)return rc;"
                )
            lines += ["  return AR_OK;", "}", ""]
            (runtime / f"{stem}.c").write_text(header + "".join(chunk) + "\n".join(lines))
            registrations.append(f"extern int ar_{prefix}_register_chunk_{index:02d}(void);\n")

        raw = elf.read_bytes()
        digest = hashlib.sha256(raw).digest()
        if manifest["source_sha256"] != digest.hex():
            raise ValueError("AOT source hash changed while building")
        install = (
            f"/* Generated PPU AOT registration batch for prefix {prefix}. */\n"
            "#include <stddef.h>\n#include <stdint.h>\n#include <string.h>\n"
            "#include \"ppu_bridge.h\"\n"
            + "".join(registrations)
            + "static const uint8_t source_sha256[32]={"
            + ", ".join(f"0x{x:02x}" for x in digest) + "};\n"
            + f"int ar_{prefix}_offline_aot_install_sha256(const uint8_t *digest,size_t size){{\n"
            + "  if(!digest||size!=32u||memcmp(digest,source_sha256,32u))return AR_BAD_ARGS;\n"
        )
        for index in range(len(chunks)):
            install += f"  {{int rc=ar_{prefix}_register_chunk_{index:02d}();if(rc!=AR_OK)return rc;}}\n"
        install += "  return AR_OK;\n}\n"
        (runtime / f"ppu_{prefix}_offline_aot_install.c").write_text(install)
        shutil.copy2(tmpdir / "aot-manifest.json", output / "aot-manifest.json")

    symbols = [f"{newstem}{int(row['start'], 0):08x}" for row in manifest["accepted"]]
    (output / "symbols.txt").write_text("\n".join(symbols) + "\n")
    summary = {
        "schema": "ascension-recomp/ppu-aot-split-batch-v1",
        "source_sha256": manifest["source_sha256"],
        "candidate_functions": manifest["candidates"],
        "native_functions": manifest["generated_functions"],
        "rejected_functions": manifest["rejected_functions"],
        "translated_ppc_instructions": sum(x["instructions"] for x in manifest["accepted"]),
        "module_count": len(chunks),
        "maximum_module_bytes": max(p.stat().st_size for p in runtime.glob(f"ppu_{prefix}_offline_aot_[0-9][0-9].c")),
        "warning": "Static AOT candidate batch; compile/link and device execution are separate evidence gates."
    }
    (output / "batch-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--elf", required=True, type=Path)
    parser.add_argument("--functions", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--prefix", default="m740")
    parser.add_argument("--max-chunk-bytes", type=int, default=2_250_000)
    parser.add_argument("--require-entry", type=lambda x: int(x, 0), default=None)
    args = parser.parse_args()
    summary = split_batch(args.elf, args.functions, args.output_dir, args.prefix,
                          args.max_chunk_bytes, args.require_entry)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
