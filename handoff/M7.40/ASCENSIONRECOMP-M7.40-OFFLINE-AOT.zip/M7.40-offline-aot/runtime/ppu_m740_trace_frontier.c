/* M7.40 trace-seeded PPC block compiled as host-native C/ARM64.
 * Seed is the M7.36 observed unresolved PC 0x00524C54. This is one
 * eight-instruction block, not a full function or game recompilation.
 */
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "ppu_bridge.h"
#include <stdint.h>
#include "ppu_context.h"
typedef ppu_context ppu_ctx;
typedef uint64_t u64;
typedef uint32_t u32;
typedef int32_t s32;
extern u64 ar_read64(u64);
extern u32 ar_read32(u64);
extern uint16_t ar_read16(u64);
extern uint8_t ar_read8(u64);
extern void ar_write64(u64,u64);
extern void ar_write32(u64,u32);
extern void ar_write16(u64,uint16_t);
extern void ar_write8(u64,uint8_t);
extern int ar_guest_call(ppu_ctx*, u64);
extern int ar_guest_syscall(ppu_ctx*);
/* 0: return to guest LR; 1: tail dispatch; negative: host failure */
static inline __attribute__((unused)) u32 ar_rotl32(u32 v, unsigned sh) {
    sh &= 31U; return sh ? (u32)((v<<sh) | (v>>(32U-sh))) : v;
}
static inline __attribute__((unused)) u64 ar_rotl64(u64 v, unsigned sh) {
    sh &= 63U; return sh ? ((v<<sh) | (v>>(64U-sh))) : v;
}
static inline __attribute__((unused)) u64 ar_data32(u32 v) {
    return ((u64)v << 32) | (u64)v;
}

extern int ar_m712_exec_window(const uint8_t *,size_t,uint32_t,uint32_t[6]);
int ar_m740_trace_00524c54(ppu_ctx *c) {
    L_524c54: ;
    c->gpr[6] = c->gpr[6] * (u64)((int64_t)3600);
    L_524c58: ;
    c->gpr[6]=c->gpr[6]+c->gpr[5];
    L_524c5c: ;
    c->gpr[9] = c->gpr[9] + (u64)((int64_t)-20864);
    L_524c60: ;
    c->gpr[10]=c->gpr[10]+c->gpr[6];
    L_524c64: ;
    c->gpr[10]=(u64)(int64_t)(s32)(u32)c->gpr[10];
    L_524c68: ;
    c->gpr[0]=c->gpr[0]+c->gpr[10];
    L_524c6c: ;
    c->gpr[9]=c->gpr[9]+c->gpr[0];
    c->cr=(c->cr & ~(15U << 28)) | (u32)((((((int64_t)c->gpr[9] < 0LL) ? 8U : (((int64_t)c->gpr[9] > 0LL) ? 4U : 2U))) | ((c->xer >> 31)&1U)) << 28);
    L_524c70: ;
    if ((((c->cr >> 31) & 1U) == 1U)) {
    c->cia=0x524cfcULL; return 1;
    }
    c->cia=0x524c74ULL; return 1;
}

static const uint32_t ar_m740_frontier_words[8]={UINT32_C(0x1cc60e10), UINT32_C(0x7cc62a14), UINT32_C(0x3929ae80), UINT32_C(0x7d4a3214), UINT32_C(0x7d4a07b4), UINT32_C(0x7c005214), UINT32_C(0x7d290215), UINT32_C(0x4180008c)};
int ar_m740_register_frontier(const uint8_t *elf,size_t length,
    const uint8_t *digest,size_t digest_size){
  static const uint8_t expected_sha[32]={0x4b, 0xf7, 0x5c, 0x89, 0x7b, 0x82, 0xd1, 0xbe, 0xb2, 0x55, 0x14, 0xcb, 0xad, 0xaf, 0xf3, 0xd0, 0x3e, 0x1b, 0x0c, 0x7b, 0xf8, 0x49, 0xfa, 0x5d, 0x28, 0x9b, 0xe4, 0xf9, 0x18, 0x34, 0x62, 0xb5};
  if(!elf||length<64u||!digest||digest_size!=32u||
     memcmp(digest,expected_sha,32u))return AR_BAD_ARGS;
  uint64_t h=UINT64_C(14695981039346656037);
  for(unsigned base=0;base<8u;base+=4u){
    uint32_t window[6]={0};
    if(ar_m712_exec_window(elf,length,UINT32_C(0x00524c54)+base*4u,window)!=AR_OK||
       window[4]<(8u-base<4u?8u-base:4u)||!(window[5]&1u))return AR_BAD_ARGS;
    for(unsigned k=0;k<(8u-base<4u?8u-base:4u);k++){
      const unsigned n=base+k;const uint32_t w=window[k];
      if(w!=ar_m740_frontier_words[n]||
         ar_read32(UINT32_C(0x00524c54)+4u*n)!=w||ar_last_error()!=AR_OK)
        return AR_BAD_ARGS;
      for(unsigned q=0;q<4u;q++){h^=(uint8_t)(w>>(24u-8u*q));
        h*=UINT64_C(1099511628211);}
    }
  }
  if(h!=UINT64_C(0xbfdc5eca6e5080e0))return AR_BAD_ARGS;
  const int rc=ar_register(UINT32_C(0x00524c54),ar_m740_trace_00524c54);
  return rc==AR_DUPLICATE?AR_OK:rc;
}
