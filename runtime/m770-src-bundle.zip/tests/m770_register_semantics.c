
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include "ppu_bridge.h"
static struct{uint32_t pc;ar_ppu_fn fn;} tab[12];
static unsigned n;
ar_ppu_fn ar_registered_handler(uint32_t pc){for(unsigned i=0;i<n;i++)if(tab[i].pc==pc)return tab[i].fn;return 0;}
int ar_register(uint32_t pc,ar_ppu_fn f){if(ar_registered_handler(pc))return AR_DUPLICATE;tab[n].pc=pc;tab[n++].fn=f;return AR_OK;}
static int handlerA(ppu_context *p){(void)p;return 0;}
static int handlerB(ppu_context *p){(void)p;return 0;}
/* M7.70: counts refer to actual registrations in the RUNNING bridge.
 * Indices: examined/new/same-handler-duplicate/conflict/rejected/failure/frontier-match.
 * Distinct from the 3,835 offline C generation count.
 */
static uint32_t m770_stats[7];
static ar_ppu_fn m770_conflicting_frontier_handler;
void ar_m770_delta_get_stats(uint32_t out[7]) {
    if (out) memcpy(out,m770_stats,sizeof(m770_stats));
}
ar_ppu_fn ar_m770_delta_prior_frontier_handler(void) {
    return m770_conflicting_frontier_handler;
}
static int m770_protected_prx(uint32_t pc) {
    static const uint32_t veneers[] = {
        0x006698fcu,0x00669934u,0x00669a84u,0x00669abcu,
        0x00669cb4u,0x00669e04u,0x00669eacu
    };
    for (size_t i=0;i<sizeof(veneers)/sizeof(veneers[0]);++i)
        if (pc==veneers[i]) return 1;
    return 0;
}
/* Existing ar_register() returns AR_DUPLICATE WITHOUT replacing the pointer.
 * The adapter checks the effective PC->handler association on every candidate.
 */
static int m770_register_checked(uint32_t pc, ar_ppu_fn handler) {
    ++m770_stats[0];
    if (!pc || (pc&3u) || !handler || m770_protected_prx(pc)) {
        ++m770_stats[4];
        return AR_OK; /* do not overwrite imported PRX or HLE entries */
    }
    ar_ppu_fn prior=ar_registered_handler(pc);
    if (prior) {
        if (prior==handler) ++m770_stats[2];
        else {
            ++m770_stats[3];
            if (pc==0x0052a740u) {
                m770_conflicting_frontier_handler=prior;
                ++m770_stats[5];
                return AR_DUPLICATE; /* diagnostic fails closed */
            }
        }
        return AR_OK; /* keep original handler, never claim it was replaced */
    }
    const int rc=ar_register(pc,handler);
    if (rc==AR_OK) {
        if (ar_registered_handler(pc)!=handler) {
            ++m770_stats[5]; return AR_BAD_ARGS;
        }
        ++m770_stats[1];
        return AR_OK;
    }
    if (rc==AR_DUPLICATE) {
        prior=ar_registered_handler(pc);
        if (prior==handler) ++m770_stats[2];
        else {
            ++m770_stats[3];
            if (pc==0x0052a740u) m770_conflicting_frontier_handler=prior;
            ++m770_stats[5];
            return AR_DUPLICATE;
        }
        return AR_OK;
    }
    ++m770_stats[5];
    return rc;
}


int main(void){
 assert(m770_register_checked(0x00100000u,handlerA)==AR_OK);
 assert(m770_register_checked(0x00100000u,handlerA)==AR_OK);
 assert(m770_register_checked(0x00100000u,handlerB)==AR_OK);
 assert(ar_registered_handler(0x00100000u)==handlerA);
 assert(m770_register_checked(0x00669a84u,handlerB)==AR_OK);
 assert(ar_registered_handler(0x00669a84u)==0);
 assert(m770_register_checked(0x0052a740u,handlerA)==AR_OK);
 assert(m770_register_checked(0x0052a740u,handlerB)==AR_DUPLICATE);
 assert(ar_m770_delta_prior_frontier_handler()==handlerA);
 uint32_t o[7]={0};ar_m770_delta_get_stats(o);
 assert(o[0]==6 && o[1]==2 && o[2]==1 && o[3]==2 && o[4]==1 && o[5]==1 && o[6]==0);
 puts("M770 registrar: new=2 same=1 conflict=2 PRX_rejected=1 frontier_conflict=fails_closed PASS");
 return 0;
}
