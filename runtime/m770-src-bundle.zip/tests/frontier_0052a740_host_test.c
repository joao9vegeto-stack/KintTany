#include <assert.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "ppu_context.h"
typedef ppu_context ppu_ctx;
typedef uint64_t u64;
typedef uint32_t u32;
typedef int32_t s32;
static u64 mem_addr[16];
static u64 mem_value[16];
static unsigned mem_used;
static unsigned guest_calls;
static u64 guest_target;
static void mem_set(u64 address, u64 value) {
    for (unsigned i = 0; i < mem_used; ++i) if (mem_addr[i] == address) { mem_value[i] = value; return; }
    assert(mem_used < 16); mem_addr[mem_used] = address; mem_value[mem_used++] = value;
}
static u64 mem_get(u64 address) {
    for (unsigned i = 0; i < mem_used; ++i) if (mem_addr[i] == address) return mem_value[i];
    assert(!"unexpected guest memory read"); return 0;
}
static inline u32 ar_rotl32(u32 v, unsigned sh) { sh &= 31U; return sh ? (u32)((v << sh) | (v >> (32U - sh))) : v; }
static inline u64 ar_rotl64(u64 v, unsigned sh) { sh &= 63U; return sh ? ((v << sh) | (v >> (64U - sh))) : v; }
static inline u64 ar_data32(u32 v) { return ((u64)v << 32) | (u64)v; }
static u32 ar_read32(u64 address) { return (u32)mem_get(address); }
static u64 ar_read64(u64 address) { return mem_get(address); }
static void ar_write64(u64 address, u64 value) { mem_set(address, value); }
static int ar_guest_call(ppu_ctx *c, u64 target) { (void)c; ++guest_calls; guest_target = target; return 0; }

int ar_m770_delta_ppu_0052a740(ppu_ctx *c) {
    L_52a740: ;
    c->gpr[10]=(u64)ar_read32(c->gpr[2]+(u64)((int64_t)-22968));
    L_52a744: ;
    c->gpr[0]=c->lr;
    L_52a748: ;
    u64 ea_2=c->gpr[1]+(u64)((int64_t)-112);
    ar_write64(ea_2, c->gpr[1]);
    c->gpr[1]=ea_2;
    L_52a74c: ;
    u64 ea_3=c->gpr[1]+(u64)((int64_t)128);
    ar_write64(ea_3, c->gpr[0]);
    L_52a750: ;
    u32 rot32_4=ar_rotl32((u32)c->gpr[3],5);
    u64 data64_4=ar_data32(rot32_4);
    c->gpr[11]=data64_4 & 0x00000000ffffffe0ULL;
    L_52a754: ;
    u32 rot32_5=ar_rotl32((u32)c->gpr[3],3);
    u64 data64_5=ar_data32(rot32_5);
    c->gpr[0]=data64_5 & 0x00000000fffffff8ULL;
    L_52a758: ;
    c->gpr[9]=(u64)ar_read32(c->gpr[10]+(u64)((int64_t)0));
    L_52a75c: ;
    c->gpr[8] = c->gpr[10] + (u64)((int64_t)8);
    L_52a760: ;
    c->gpr[0]=c->gpr[0]+c->gpr[11];
    L_52a764: ;
    c->cr=(c->cr & ~(15U << 0)) | (u32)((((((s32)(u32)c->gpr[9] < (s32)(u32)c->gpr[3]) ? 8U : (((s32)(u32)c->gpr[9] > (s32)(u32)c->gpr[3]) ? 4U : 2U))) | ((c->xer >> 31)&1U)) << 0);
    L_52a768: ;
    c->gpr[0]=c->gpr[0]+c->gpr[8];
    L_52a76c: ;
    u64 rot_11=ar_rotl64(c->gpr[0], 0);
    c->gpr[3]=rot_11 & 0x00000000ffffffffULL;
    L_52a770: ;
    if ((((c->cr >> 2) & 1U) == 0U)) {
    goto L_52a77c;
    }
    L_52a774: ;
    c->lr=0x52a778ULL;
    if(ar_guest_call(c,0x52e3f4ULL)) return -3;
    L_52a778: ;
    c->gpr[0] = c->gpr[0] | 0x0ULL;
    L_52a77c: ;
    c->gpr[0]=(u64)ar_read64(c->gpr[1]+(u64)((int64_t)128));
    L_52a780: ;
    c->gpr[1] = c->gpr[1] + (u64)((int64_t)112);
    L_52a784: ;
    c->lr=c->gpr[0];
    L_52a788: ;
    u64 target_18=c->lr;
    if(1) {
    c->cia=target_18; return 0;
    }
}
static void run_case(u32 compare_value, unsigned expected_calls, u32 expected_cr0) {
    ppu_context c; ppu_context_init(&c);
    memset(mem_addr, 0, sizeof(mem_addr)); memset(mem_value, 0, sizeof(mem_value)); mem_used = 0;
    guest_calls = 0; guest_target = 0;
    const u64 toc = 0x100000, target_ptr = 0x200000, sp = 0x300000, lr = 0xDEADBEEF;
    mem_set(toc - 22968, target_ptr);
    mem_set(target_ptr, compare_value);
    c.gpr[1] = sp; c.gpr[2] = toc; c.gpr[3] = 10; c.lr = lr;
    const int rc = ar_m770_delta_ppu_0052a740(&c);
    assert(rc == 0);
    assert(guest_calls == expected_calls);
    if (expected_calls) assert(guest_target == 0x52e3f4ULL);
    assert((c.cr & 0xFU) == expected_cr0);
    assert(c.gpr[1] == sp);
    assert(c.gpr[2] == toc);
    assert(c.lr == lr);
    assert(c.cia == lr);
    assert(c.gpr[3] == 0x200198ULL);
}
int main(void) {
    run_case(5, 0, 8);   /* r9 < r3: branch to 0x0052A77C, no BL */
    run_case(20, 1, 4);  /* r9 > r3: BL to 0x0052E3F4 */
    puts("M770 frontier 0x0052A740 host semantic test PASS (LT path, BL path, LR, stack, TOC, result)");
    return 0;
}
